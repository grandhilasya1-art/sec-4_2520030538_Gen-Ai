
from transformers import AutoTokenizer
import csv

# --------------------------------------------------
# PART 1: ENGLISH, TELUGU AND HINDI TOKEN COMPARISON
# --------------------------------------------------

sentences = {
    "English": "Artificial Intelligence helps students learn new technologies.",
    "Telugu": "కృత్రిమ మేధస్సు విద్యార్థు లకు కొత్త సాంకేతికతలను నేర్చుకోవడంలో సహాయపడుతుంది.",
    "Hindi": "कृ त्रिम बुद्धिमत्ता छात्रों को नई तकनीक सीखने में मदद करती है।"
}

tokenizer_models = {
    "BPE (GPT-2)": {
        "model": "openai-community/gpt2",
        "use_fast": True
    },
    "WordPiece (Multilingual BERT)": {
        "model": "google-bert/bert-base-multilingual-cased",
        "use_fast": True
    },
    "SentencePiece (mT5)": {
        "model": "google/mt5-small",
        "use_fast": False
    }
}

print("\n======================================")
print("WEEK 5: TOKENIZATION COMPARISON")
print("======================================")

# Load tokenizers
loaded_tokenizers = {}

for name, config in tokenizer_models.items():

    print("\nLoading:", name)

    tokenizer = AutoTokenizer.from_pretrained(
        config["model"],
        use_fast=config["use_fast"]
    )

    loaded_tokenizers[name] = tokenizer

    print("Loaded successfully!")

# Tokenize sentences
token_results = []

for language, sentence in sentences.items():

    print("\n--------------------------------------")
    print("Language:", language)
    print("Sentence:", sentence)

    word_count = len(sentence.split())

    for tokenizer_name, tokenizer in loaded_tokenizers.items():

        token_ids = tokenizer.encode(
            sentence,
            add_special_tokens=False
        )

        tokens = tokenizer.convert_ids_to_tokens(token_ids)

        token_count = len(token_ids)

        token_ratio = (
            token_count / word_count
            if word_count > 0 else 0
        )

        print("\nTokenizer:", tokenizer_name)
        print("Tokens:", tokens)
        print("Word Count:", word_count)
        print("Token Count:", token_count)
        print("Token Ratio:", round(token_ratio, 3))

        token_results.append({
            "Language": language,
            "Tokenizer": tokenizer_name,
            "Word_Count": word_count,
            "Token_Count": token_count,
            "Token_Ratio": round(token_ratio, 3)
        })

# Save tokenizer comparison to CSV
with open(
    "week5_token_comparison.csv",
    "w",
    newline="",
    encoding="utf-8-sig"
) as file:

    fieldnames = [
        "Language",
        "Tokenizer",
        "Word_Count",
        "Token_Count",
        "Token_Ratio"
    ]

    writer = csv.DictWriter(
        file,
        fieldnames=fieldnames
    )

    writer.writeheader()
    writer.writerows(token_results)

print("\nToken comparison saved successfully!")


# --------------------------------------------------
# PART 2: API COST CALCULATION
# --------------------------------------------------

INPUT_RATE = 0.50
OUTPUT_RATE = 2.00

students = 1000
requests_per_student = 10

input_tokens_per_request = 1500
output_tokens_per_request = 500

days_per_month = 30

total_requests = students * requests_per_student

total_input_tokens = total_requests * input_tokens_per_request
total_output_tokens = total_requests * output_tokens_per_request

input_cost = total_input_tokens * INPUT_RATE / 1_000_000
output_cost = total_output_tokens * OUTPUT_RATE / 1_000_000

daily_cost = input_cost + output_cost
monthly_cost = daily_cost * days_per_month

print("\n======================================")
print("PART 2: API COST CALCULATION")
print("======================================")

print("Total Requests:", total_requests)
print("Total Input Tokens:", total_input_tokens)
print("Total Output Tokens:", total_output_tokens)

print("Input Cost: $", input_cost)
print("Output Cost: $", output_cost)

print("Daily Cost: $", daily_cost)
print("Monthly Cost: $", monthly_cost)

# --------------------------------------------------
# PART 3: CONTEXT WINDOW CALCULATION
# --------------------------------------------------

context_window = 128000

system_tokens = 2000
conversation_tokens = 10000
user_input_tokens = 1500

used_context = (
    system_tokens
    + conversation_tokens
    + user_input_tokens
)

remaining_context = context_window - used_context

print("\n======================================")
print("PART 3: CONTEXT WINDOW CALCULATION")
print("======================================")

print("Total Context Window:", context_window)
print("System Tokens:", system_tokens)
print("Conversation Tokens:", conversation_tokens)
print("User Input Tokens:", user_input_tokens)

print("Used Context:", used_context)
print("Remaining Context:", remaining_context)

# --------------------------------------------------
# PART 4: FINAL SUMMARY
# --------------------------------------------------

print("\n======================================")
print("PART 4: FINAL SUMMARY")
print("======================================")

print("1. Language token comparison completed.")
print("2. Input and output token costs calculated.")
print("3. Daily and monthly budgets calculated.")
print("4. Context window usage calculated.")

print("\nGenerated File: week5_token_comparison.csv")

print("\nWEEK 5 LAB COMPLETED SUCCESSFULLY!")
